Group A 
Name: (Roll Number)
Rohit Kumar, 120050028
Suman Sourabh, 120050031

Group B
Name: (Roll Number)
Rakesh Ranjan nayak, 120050047
Nitin Chandrol, 120050035


Add a well documented and commented code of your experiments in the respective folders.
