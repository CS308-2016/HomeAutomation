2016 - CS308  Group 4 : Project README TEMPLATE 
================================================ 
 
Group Info: 
------------ 
Suman Sourabh (120050031)
Rohit Kumar (120050028)
Nitin Chandrol (120050035)
Rakesh Ranjan Nayak (120050047)
 
Project Description 
------------------- 

We worked on the Home Automation problem. Our mission to provide convenience, comfort and energy efficiency in household activities through automation. It provides centralized control of home appliances activity through Mobile application. Sensors like Motion sensor, proximity sensor and temperature sensor are used to detect the activities and state of environment and notify user about it using bluetooth network. 
It is useful in home, offices and schools etc. Thus impacts a large number of people.  
 
Technologies Used 
------------------- 
 
Remove the items that do no apply to your project and keep the remaining ones. 

+   CCS
+   Embedded C     
 
 
Installation Instructions 
========================= 
1. Install CCS: http://processors.wiki.ti.com/index.php/Download_CCS

 
Demonstration Video 
=========================  
Demo link: 	https://www.youtube.com/watch?v=ApprhI0AtJk
Screen cast video: 	https://www.youtube.com/watch?v=_gTaJjF6ZtA&feature=youtu.be

References 
=========== 
 
Please give references to importance resources.  
 
+ Home automation using Bluetooth Device 
	https://www.youtube.com/watch?v=RwECaBf­ZpA  
+ TIVA Board getting started 
        ​https://www.youtube.com/watch?v=JpGNNCYjtFw 


