Project Name: Automators (Home automation module)

Team Members:
1. Rohit Kumar
2. Rakesh Ranjan Nayak
3. Suman Sourabh
4. Nitin Chandrol

Project Description:
We worked on the Home Automation problem. Our mission to provide convenience, comfort and energy efficiency in household activities through automation. It provides centralized control of home appliances activity through Mobile application. Sensors like Motion sensor, proximity sensor and temperature sensor are used to detect the activities and state of environment and notify user about it using bluetooth network. 
It is useful in home, offices and schools etc. Thus impacts a large number of people. 
